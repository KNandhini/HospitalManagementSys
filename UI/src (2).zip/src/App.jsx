import { useLocation } from "react-router-dom";
import Navbar from "./components/layout/Navbar";
import AppRoutes from "./routes/AppRoutes";

function App() {
  const { pathname } = useLocation();
  const useSidebarShell = pathname.startsWith("/doctor-schedule");

  return (
    <>
      {!useSidebarShell && <Navbar />}
      <main style={useSidebarShell ? undefined : { padding: "1.5rem" }}>
        <AppRoutes />
      </main>
    </>
  );
}

export default App;