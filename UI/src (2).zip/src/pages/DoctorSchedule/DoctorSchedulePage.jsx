import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import Swal from "sweetalert2";
import Sidebar from "../../components/layout/Sidebar";
import TopHeader from "../../components/layout/TopHeader";
import UpdateAvailabilityPanel from "./UpdateAvailabilityPanel";
import { updateDoctorAvailability } from "../../api/doctorApi";
import "../../styles.css";


// TODO(auth): once login exists, replace this with the logged-in doctor
// from useAuth() / getDoctorById(currentUserId). Everything below reads
// only from this object, so swapping the source is a one-line change.
const DOCTOR = {
  doctorId: "DOC-1042",
  firstName: "Anjali",
  lastName: "Sharma",
  specialization: "Cardiologist",
  qualification: "MBBS, MD (Cardiology)",
  yearsOfExperience: 10,
  mobileNumber: "+91 98765 43210",
  photoUrl: "",
  availableDays: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  availableTimeFrom: "09:00",
  availableTimeTo: "20:00",
};

// A one-off leave block layered on top of the recurring weekly hours
// above — demonstrates "On Leave" without touching the doctor's normal
// working days. Replace with real data from getDoctorAvailability().
const LEAVE_BLOCKS = [
  { weekday: "Wed", from: "14:00", to: "14:30" },
];

const SHIFTS = [
  { label: "Morning", start: "09:00", end: "12:00" },
  { label: "Afternoon", start: "13:00", end: "17:00" },
  { label: "Evening", start: "17:00", end: "20:00" },
];

const WEEKDAY_KEYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const STATUS_LABELS = {
  Available: "Available",
  Booked: "Booked",
  OnLeave: "On Leave",
  NotAvailable: "Not Available",
};

function pad(n) {
  return String(n).padStart(2, "0");
}

function toISODate(date) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function addDays(date, n) {
  const d = new Date(date);
  d.setDate(d.getDate() + n);
  return d;
}

function startOfWeek(date) {
  const d = new Date(date);
  d.setDate(d.getDate() - d.getDay() + 1); // Monday-start week, matching the reference layout
  return d;
}

function timeToMinutes(t) {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

function minutesToTime(mins) {
  return `${pad(Math.floor(mins / 60))}:${pad(mins % 60)}`;
}

function formatSlotLabel(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  const period = h >= 12 ? "PM" : "AM";
  const display = h % 12 === 0 ? 12 : h % 12;
  return `${display}:${pad(m)} ${period}`;
}

function formatDayLabel(date) {
  return date.toLocaleDateString(undefined, { weekday: "short" });
}

// Deterministic pseudo-random booking, seeded per day/time so the grid
// looks stable across re-renders instead of reshuffling.
function seededBooked(dateISO, mins) {
  let h = 0;
  const str = `${dateISO}-${mins}`;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) | 0;
  return Math.abs(h) % 100 < 38; // ~38% of in-hours slots come back booked
}

function buildWeekSchedule(weekStart, doctor) {
  const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  const schedule = {};

  days.forEach((date) => {
    const iso = toISODate(date);
    const weekdayKey = WEEKDAY_KEYS[date.getDay()];
    const working = doctor.availableDays.includes(weekdayKey);
    const fromMin = timeToMinutes(doctor.availableTimeFrom);
    const toMin = timeToMinutes(doctor.availableTimeTo);
    const leave = LEAVE_BLOCKS.find((l) => l.weekday === weekdayKey);

    schedule[iso] = {};

    SHIFTS.forEach((shift) => {
      for (let mins = timeToMinutes(shift.start); mins < timeToMinutes(shift.end); mins += 30) {
        const time = minutesToTime(mins);

        if (!working || mins < fromMin || mins >= toMin) {
          schedule[iso][time] = "NotAvailable";
        } else if (leave && mins >= timeToMinutes(leave.from) && mins < timeToMinutes(leave.to)) {
          schedule[iso][time] = "OnLeave";
        } else if (seededBooked(iso, mins)) {
          schedule[iso][time] = "Booked";
        } else {
          schedule[iso][time] = "Available";
        }
      }
    });
  });

  return { days, schedule };
}

export default function DoctorSchedulePage() {
  const [weekStart, setWeekStart] = useState(() => startOfWeek(new Date()));
  const [selectedDayISO, setSelectedDayISO] = useState(() => toISODate(new Date()));
  const [panelOpen, setPanelOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const { days, schedule } = useMemo(
    () => buildWeekSchedule(weekStart, DOCTOR),
    [weekStart]
  );

  const stats = useMemo(() => {
    let booked = 0;
    let available = 0;
    let onLeaveDays = new Set();

    Object.entries(schedule).forEach(([iso, slots]) => {
      Object.entries(slots).forEach(([, status]) => {
        if (status === "Booked") booked++;
        if (status === "Available") available++;
        if (status === "OnLeave") onLeaveDays.add(iso);
      });
    });

    const total = booked + available;
    return {
      totalAppointments: booked,
      bookedSlots: booked,
      bookedPct: total ? Math.round((booked / total) * 100) : 0,
      availableSlots: available,
      availablePct: total ? Math.round((available / total) * 100) : 0,
      onLeaveCount: onLeaveDays.size,
    };
  }, [schedule]);

  const getBookedCount = (dateFromISO, dateToISO, timeFrom, timeTo) => {
    let count = 0;
    const from = new Date(`${dateFromISO}T00:00:00`);
    const to = new Date(`${dateToISO}T00:00:00`);
    const fromMin = timeToMinutes(timeFrom);
    const toMin = timeToMinutes(timeTo);

    for (let d = new Date(from); d <= to; d = addDays(d, 1)) {
      const iso = toISODate(d);
      const daySlots = schedule[iso];
      if (!daySlots) continue;
      Object.entries(daySlots).forEach(([time, status]) => {
        const mins = timeToMinutes(time);
        if (status === "Booked" && mins >= fromMin && mins < toMin) count++;
      });
    }
    return count;
  };

  const handleUpdateAvailability = async (payload) => {
    setSaving(true);
    try {
      await updateDoctorAvailability(DOCTOR.doctorId, payload);
      setPanelOpen(false);
      Swal.fire({
        icon: "success",
        title: "Availability updated",
        text: `Your schedule was updated for ${payload.dateFrom === payload.dateTo ? payload.dateFrom : `${payload.dateFrom} – ${payload.dateTo}`}.`,
        confirmButtonColor: "var(--color-primary)",
        timer: 2000,
        timerProgressBar: true,
      });
    } catch (err) {
      console.error("Update availability failed:", err);
      Swal.fire({
        icon: "error",
        title: "Couldn't update availability",
        text: err?.response?.data?.message || err?.message || "Please try again.",
        confirmButtonColor: "var(--color-primary)",
      });
    } finally {
      setSaving(false);
    }
  };

  const rangeLabel = `${days[0].toLocaleDateString(undefined, { day: "numeric", month: "short" })} – ${days[6].toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}`;

  return (
    <div className="hh-shell">
      <Sidebar />

      <div className="hh-shell-main">
        <TopHeader doctor={DOCTOR} notificationCount={3} />

        <div className="hh-shell-body">
          <div className={`hh-schedule-content ${panelOpen ? "with-panel" : ""}`}>
            <Link to="/dashboard" className="hh-back-link">
              ← Back to Schedule
            </Link>

            <div className="app-header" style={{ marginTop: 6 }}>
              <div>
                <h1>My Schedule</h1>
                <p>View and manage your availability, appointments and update your schedule.</p>
              </div>
            </div>

            <div className="hh-doctor-bar">
              <div className="hh-doctor-summary">
                {DOCTOR.photoUrl ? (
                  <img src={DOCTOR.photoUrl} alt="" className="hh-doctor-photo" />
                ) : (
                  <span className="hh-doctor-photo hh-doctor-photo-initials">
                    {DOCTOR.firstName[0]}
                    {DOCTOR.lastName[0]}
                  </span>
                )}
                <div>
                  <div className="hh-doctor-name">
                    Dr. {DOCTOR.firstName} {DOCTOR.lastName}
                  </div>
                  <div className="hh-doctor-role">{DOCTOR.specialization}</div>
                  <div className="hh-doctor-meta">
                    <span>🎓 {DOCTOR.qualification}</span>
                    <span>🕒 {DOCTOR.yearsOfExperience}+ Years Experience</span>
                    <span>📞 {DOCTOR.mobileNumber}</span>
                  </div>
                </div>
              </div>

              <div className="hh-doctor-bar-right">
                <div className="hh-week-nav">
                  <span className="hh-week-nav-icon">🗓️</span>
                  <span className="hh-week-nav-label">{rangeLabel}</span>
                  <button className="btn btn-secondary btn-icon" onClick={() => setWeekStart((w) => addDays(w, -7))} aria-label="Previous week">
                    ‹
                  </button>
                  <button className="btn btn-secondary btn-icon" onClick={() => setWeekStart((w) => addDays(w, 7))} aria-label="Next week">
                    ›
                  </button>
                </div>

                <div className="sched-view-toggle">
                  <button className="active">Week</button>
                </div>

                <button className="btn btn-primary" onClick={() => setPanelOpen(true)}>
                  🗓️ Update Availability
                </button>
              </div>
            </div>

            <div className="app-stats">
              <StatCard icon="📅" label="Total Appointments" value={stats.totalAppointments} sub="+12% than last week" tone="success" />
              <StatCard icon="✅" label="Booked Slots" value={stats.bookedSlots} sub={`${stats.bookedPct}% of total slots`} tone="accent" />
              <StatCard icon="⏰" label="Available Slots" value={stats.availableSlots} sub={`${stats.availablePct}% of total slots`} tone="primary" />
              <StatCard icon="🧍" label="On Leave" value={stats.onLeaveCount} sub="This week" tone="warning" />
            </div>

            <div className="hh-day-tabs">
              {days.map((date) => {
                const iso = toISODate(date);
                return (
                  <button
                    key={iso}
                    className={`hh-day-tab ${iso === selectedDayISO ? "active" : ""}`}
                    onClick={() => setSelectedDayISO(iso)}
                  >
                    <span className="hh-day-tab-name">{formatDayLabel(date)}</span>
                    <span className="hh-day-tab-date">{date.getDate()} {date.toLocaleDateString(undefined, { month: "short" })}</span>
                  </button>
                );
              })}
            </div>

            <div className="hh-week-grid-wrap">
              <div className="hh-week-grid">
                <div className="hh-week-grid-headrow">
                  <div className="hh-week-grid-timecol" />
                  {days.map((date) => {
                    const iso = toISODate(date);
                    return (
                      <div key={iso} className={`hh-week-grid-daycol-head ${iso === selectedDayISO ? "active" : ""}`}>
                        <div>{formatDayLabel(date)}</div>
                        <div className="hh-week-grid-daynum">{date.getDate()} {date.toLocaleDateString(undefined, { month: "short" })}</div>
                      </div>
                    );
                  })}
                </div>

                {SHIFTS.map((shift) => {
                  const slotTimes = [];
                  for (let m = timeToMinutes(shift.start); m < timeToMinutes(shift.end); m += 30) slotTimes.push(m);

                  return (
                    <div className="hh-week-shift" key={shift.label}>
                      <div className="hh-week-shift-label">
                        {shift.label} ({formatSlotLabel(timeToMinutes(shift.start))} – {formatSlotLabel(timeToMinutes(shift.end))})
                      </div>

                      {slotTimes.map((mins) => (
                        <div className="hh-week-grid-row" key={mins}>
                          <div className="hh-week-grid-timecol">{formatSlotLabel(mins)}</div>
                          {days.map((date) => {
                            const iso = toISODate(date);
                            const status = schedule[iso]?.[minutesToTime(mins)] || "NotAvailable";
                            return (
                              <div key={iso} className={`hh-week-grid-daycol ${iso === selectedDayISO ? "active" : ""}`}>
                                <span className={`hh-status-pill hh-status-${status}`}>
                                  {STATUS_LABELS[status]}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      ))}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="hh-legend-bar">
              <div className="hh-legend-items">
                <LegendDot status="Available" /> Available
                <LegendDot status="Booked" /> Booked
                <LegendDot status="OnLeave" /> On Leave
                <LegendDot status="NotAvailable" /> Not Available
              </div>
              <button className="btn btn-secondary">👁 View Appointment Details</button>
            </div>
          </div>

          <UpdateAvailabilityPanel
            open={panelOpen}
            doctor={DOCTOR}
            saving={saving}
            onClose={() => setPanelOpen(false)}
            onSubmit={handleUpdateAvailability}
            getBookedCount={getBookedCount}
          />
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, sub, tone }) {
  return (
    <div className={`app-stat-card hh-stat-card hh-stat-${tone}`}>
      <div className="hh-stat-icon">{icon}</div>
      <div className="app-stat-label">{label}</div>
      <div className="app-stat-value">{value}</div>
      <div className="hh-stat-sub">{sub}</div>
    </div>
  );
}

function LegendDot({ status }) {
  return <span className={`hh-legend-dot hh-status-${status}`} />;
}
